#include <assert.h>
#include <stdint.h>

#include "lib.h"

int main(int argc, char** argv) {
    assert(foo() == 4);
    return 0;
}
