#[no_mangle]
pub extern "C" fn bar() -> i32 {
    4
}
