#include "lib.h"

extern int32_t bar();

int32_t foo() { return bar(); }
