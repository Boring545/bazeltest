mod generated;

pub fn main() {
    generated::greeting();
}
