#[no_mangle]
pub extern "C" fn four() -> i32 {
    4
}
