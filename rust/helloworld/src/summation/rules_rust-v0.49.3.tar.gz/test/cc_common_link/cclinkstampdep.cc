extern "C" int cclinkstampdep() { return 121; }
