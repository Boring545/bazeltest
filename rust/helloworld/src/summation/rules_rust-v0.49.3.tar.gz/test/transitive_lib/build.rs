fn main() {
    println!("cargo:rustc-link-lib=alias:shell32");
}
