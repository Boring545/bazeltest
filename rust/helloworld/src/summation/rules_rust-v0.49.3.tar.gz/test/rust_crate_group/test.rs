#[test]
fn test() {
    dep1::dep1();
    dep2::dep2();
}
