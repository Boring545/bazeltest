fn _test() {
    dep1::dep1();
    dep2::dep2();
}
