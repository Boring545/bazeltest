use math_lib::add;

#[test]
fn add_one_and_two() {
    assert_eq!(add(1, 2), 3);
}
