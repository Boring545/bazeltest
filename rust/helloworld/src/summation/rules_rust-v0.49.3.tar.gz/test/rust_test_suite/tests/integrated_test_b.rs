use math_lib::add;

#[test]
fn add_three_and_four() {
    assert_eq!(add(3, 4), 7);
}
