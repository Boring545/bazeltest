use math_lib::add;

#[test]
fn add_five_and_six() {
    assert_eq!(add(5, 6), 11);
}
