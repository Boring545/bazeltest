rust_proc_macro::ensure_proc_macro_data_exists!();

pub use rust_proc_macro::ensure_proc_macro_data_exists;
