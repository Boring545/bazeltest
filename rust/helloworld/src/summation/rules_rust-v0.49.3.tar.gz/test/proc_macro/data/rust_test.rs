nonmacro_library::ensure_proc_macro_data_exists!();
