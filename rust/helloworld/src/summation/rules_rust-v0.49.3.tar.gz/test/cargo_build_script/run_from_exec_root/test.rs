#[test]
pub fn test_tool_exec() {
    assert_eq!("Hello", env!("DATA"));
}
