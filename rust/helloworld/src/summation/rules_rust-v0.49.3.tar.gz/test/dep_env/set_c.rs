fn main() {
    println!("cargo:C=c_value");
}
