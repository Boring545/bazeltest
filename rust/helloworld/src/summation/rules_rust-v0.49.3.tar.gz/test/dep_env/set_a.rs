fn main() {
    println!("cargo:A=a_value");
}
