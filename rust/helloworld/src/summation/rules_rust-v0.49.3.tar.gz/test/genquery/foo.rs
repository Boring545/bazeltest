fn main() {
    println!("foo");
    bar::bar();
}
