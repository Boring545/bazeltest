// Analysis test shouldn't need this file.
// This is a workaround until
// https://github.com/bazelbuild/rules_rust/issues/2499
// is fixed
