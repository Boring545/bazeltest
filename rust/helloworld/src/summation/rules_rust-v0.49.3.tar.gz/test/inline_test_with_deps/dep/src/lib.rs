/// This exists purely to give us a dep to compile against
pub fn example_test_dep_fn() -> u32 {
    1
}
