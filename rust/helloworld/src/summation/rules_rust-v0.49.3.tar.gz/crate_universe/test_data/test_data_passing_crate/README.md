# test_data_passing_crate

This crate exists, and is published to crates.io, so that we can write tests for crate_universe which assert over what opt level and OUT_DIR were used when third-party crates from crates.io were being built.
