//! Module api provides a publicly consumable API over rules_rust's crate_universe.
//! While it has no formal compatibility guarantees, it is much less likely to break than other types in this library.

pub mod lockfile;
