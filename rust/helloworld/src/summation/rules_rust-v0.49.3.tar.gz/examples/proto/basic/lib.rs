extern crate common_proto_rust;

pub fn do_something(_x: &common_proto_rust::Config) -> bool {
    true
}
