pub fn print() -> String {
    "Hello Generic!".to_owned()
}
