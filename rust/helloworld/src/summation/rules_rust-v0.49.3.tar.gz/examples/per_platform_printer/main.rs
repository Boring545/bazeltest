extern crate printer;

fn main() {
    printer::print();
}
