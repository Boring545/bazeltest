package com.example.androidapp;

public class JniShim {
  public static native int getValue();
}
