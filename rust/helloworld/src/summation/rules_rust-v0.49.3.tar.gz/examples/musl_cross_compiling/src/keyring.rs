fn main() {
    println!("{}", keyring::error::Error::NoEntry);
}
