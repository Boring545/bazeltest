#include "simple.h"

EXTERN_C const int64_t simple_function() { return 1337; }
