extern "C" int cy() { return 113; }
