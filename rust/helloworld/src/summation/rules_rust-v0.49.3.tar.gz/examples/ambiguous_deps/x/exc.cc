extern "C" int cx() { return 17; }
