extern "C" int func() { return 123; }
