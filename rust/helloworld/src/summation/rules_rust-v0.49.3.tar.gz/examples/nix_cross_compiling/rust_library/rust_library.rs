#[no_mangle]
pub fn rust_double_value(value: i32) -> i32 {
    value * 2
}
