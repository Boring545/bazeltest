# Nix + Bazel Cross Compiling

Blog Post: <https://blog.consumingchaos.com/posts/nix-bazel-cross-compiling/>
