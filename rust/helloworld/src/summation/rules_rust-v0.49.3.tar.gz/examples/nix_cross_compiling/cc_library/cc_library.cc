extern "C" int cc_double_value(int value) { return value * 2; }
