mod test {
    #[test]
    pub fn test() {
        assert_eq!(foo::THE_ANSWER, 42);
    }
}
