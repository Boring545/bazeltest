fn main() {
    println!("{:?}", ring::rand::SystemRandom::new());
}
