# Rust Bindgen Rules

These rules are for using [Bindgen][bindgen] to generate [Rust][rust] bindings to C (and some C++) libraries.

See the `rules_rust` documentation for more info: https://bazelbuild.github.io/rules_rust/rust_bindgen.html

[rust]: http://www.rust-lang.org/
[bindgen]: https://github.com/rust-lang/rust-bindgen
