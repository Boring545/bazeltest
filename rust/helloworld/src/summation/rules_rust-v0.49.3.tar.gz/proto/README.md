# Rust Protobuf Rules

More information can be found in the [rules_rust documentation](https://bazelbuild.github.io/rules_rust/rust_proto.html).
