# Patches

## [protoc-gen-prost](./protoc-gen-prost.patch)

This patch addresses the issue described in https://github.com/neoeinstein/protoc-gen-prost/issues/70.
Whenever a version greater than `0.2.2` is released it can be dropped.
